"""Reproduce the four training coverage conditions, without model requests."""
import argparse
import json
from pathlib import Path
from unittest.mock import patch

from build_revision import digest, read_rows, validate_records
from ecospec_kg import analysis_v2


def evaluate(base, candidate, out):
    if out.exists():
        raise ValueError('output exists; refusing to overwrite')
    manifest = json.loads((candidate/'manifest.json').read_text(encoding='utf-8'))
    for name, relative in [('units','blind/train_units.jsonl'), ('annotations','gold/train_annotations.jsonl')]:
        if digest(base/relative) != manifest['parent_input_hashes'][name]:
            raise ValueError('parent SHA256 mismatch')
    for item in manifest['files']:
        if digest(candidate/item['path']) != item['sha256']:
            raise ValueError('candidate SHA256 mismatch: '+item['path'])
    if analysis_v2.CANDIDATE_GENERATOR_VERSION != 'structure-aware-rule-v2.4':
        raise ValueError('expected structure-aware-rule-v2.4')
    validate_records(read_rows(candidate/'blind/train_units.jsonl'), read_rows(candidate/'gold/train_annotations.jsonl'))
    matrix = {}
    for source_name, source in [('old_source',base),('reviewed_source',candidate)]:
        for label_name, labels in [('old_labels',base),('reviewed_labels',candidate)]:
            key = source_name+'__'+label_name
            # Suppress only the optional Excel view; retain the unmodified JSON analysis.
            with patch.object(analysis_v2, '_write_workbook', return_value=None):
                result = analysis_v2.analyze_training_v2(source/'blind/train_units.jsonl', labels/'gold/train_annotations.jsonl', out/key)
            fields = ('unit_count','gold_entity_count','covered_entity_count','gold_relation_count','covered_relation_count',
                      'entity_recall_upper_bound','relation_recall_upper_bound','entity_candidate_negative_count','relation_candidate_negative_count')
            matrix[key] = {field:result[field] for field in fields}
    (out/'coverage_matrix.json').write_text(json.dumps(matrix,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return matrix


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base', type=Path, required=True)
    parser.add_argument('--candidate', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(evaluate(args.base,args.candidate,args.out),ensure_ascii=False,indent=2))
