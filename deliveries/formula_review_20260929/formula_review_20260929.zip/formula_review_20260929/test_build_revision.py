import copy
import pytest
from build_revision import review_records, validate_records


def fixture():
    span = {"span_id":"s1", "page":1, "bbox":[0,0,20,20], "text":"x = y"}
    unit = {"unit_id":"u", "provenance":{"evidence_spans":[span]},
            "formulas":[{"formula_number":"1","expression_text":"x y", "expression_lines":["x y"], "evidence_span":span}],
            "variable_definitions":[{"symbol":s,"definition":s,"evidence_span":span} for s in ("x","y")]}
    entities = [{"entity_id":s,"name":name,"entity_type":kind,"evidence_span_ids":["s1"]}
                for s,name,kind in (("f","公式（1）","formula"),("x","x","model_variable"),("y","y","model_variable"))]
    annotation = {"unit_id":"u","split":"train","entities":entities,"relations":[
        {"head_id":"f","head_name":"公式（1）","head_type":"formula", "relation_type":"has_output",
         "tail_id":"y","tail_name":"y","tail_type":"model_variable","evidence_span_ids":["s1"]}]}
    decision = {"units":[{"unit_id":"u","status":"apply_candidate","reason":"fixture PDF",
                 "formulas":[{"number":"1","expression":"x = y","inputs":["y"],"outputs":["x"],"indices":[]}]}]}
    return [unit],[annotation],decision


def test_replay_preserves_original_and_replaces_roles():
    units, annotations, decision = fixture()
    snapshot = copy.deepcopy((units,annotations))
    revised, gold, log = review_records(units,annotations,decision)
    assert (units,annotations) == snapshot
    assert revised[0]["formulas"][0]["raw_expression_text"] == "x y"
    assert revised[0]["formulas"][0]["evidence_span"]["text"] == "x = y"
    keys = {(r['head_name'],r['relation_type'],r['tail_name']) for r in gold[0]['relations']}
    assert keys == {('公式（1）','has_input','y'),('公式（1）','has_output','x'),('x','calculated_by','公式（1）')}
    assert log and log[0]['unit_id'] == 'u'
    validate_records(revised,gold)


def test_nontrain_annotations_are_rejected():
    units, gold, decision=fixture(); gold[0]['split']='test'
    with pytest.raises(ValueError,match='train'):
        review_records(units,gold,decision)


def test_deferred_unit_is_unchanged():
    units,gold,decision=fixture(); decision['units'][0]['status']='deferred'
    revised, annotations, log=review_records(units,gold,decision)
    assert revised==units and annotations==gold and log==[]


def test_invalid_source_reference_is_rejected():
    units,gold,_=fixture();gold[0]['relations'][0]['evidence_span_ids']=['missing']
    with pytest.raises(ValueError,match='evidence'):
        validate_records(units,gold)


def test_input_output_overlap_is_rejected():
    units,gold,decision=fixture();decision['units'][0]['formulas'][0]['inputs']=['x']
    with pytest.raises(ValueError,match='role'):
        review_records(units,gold,decision)
