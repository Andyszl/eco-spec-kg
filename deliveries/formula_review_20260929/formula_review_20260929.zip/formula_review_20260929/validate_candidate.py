"""Validate the delivered candidate against its immutable parent and replay ledger."""
import argparse
import json
from pathlib import Path
from build_revision import digest, read_rows, review_records, validate_records
from ecospec_kg.experiment_io_v2 import assert_blind_records


def validate(base, candidate):
    manifest=json.loads((candidate/'manifest.json').read_text(encoding='utf-8'))
    spec=json.loads((candidate/'review/decisions.json').read_text(encoding='utf-8'))
    for key, relative in [('units','blind/train_units.jsonl'),('annotations','gold/train_annotations.jsonl')]:
        if digest(base/relative)!=manifest['parent_input_hashes'][key]:
            raise ValueError('parent SHA256 mismatch')
    for item in manifest['files']:
        if digest(candidate/item['path'])!=item['sha256']:
            raise ValueError('candidate SHA256 mismatch: '+item['path'])
    units=read_rows(base/'blind/train_units.jsonl'); labels=read_rows(base/'gold/train_annotations.jsonl')
    new_units=read_rows(candidate/'blind/train_units.jsonl'); new_labels=read_rows(candidate/'gold/train_annotations.jsonl')
    replay_units,replay_labels,replay_ledger=review_records(units,labels,spec)
    assert replay_units==new_units and replay_labels==new_labels
    # JSON arrays serialize the in-memory relation-key tuples as lists.
    assert json.loads(json.dumps(replay_ledger))==read_rows(candidate/'review/revision_ledger.jsonl')
    assert_blind_records(new_units)
    validate_records(new_units,new_labels)
    changed={u['unit_id'] for u,v,a,b in zip(units,new_units,labels,new_labels) if u!=v or a!=b}
    expected={d['unit_id'] for d in spec['units'] if d['status']=='apply_candidate'}
    assert changed==expected
    assert [u['unit_id'] for u in units]==[u['unit_id'] for u in new_units]
    assert [u['unit_id'] for u in labels]==[u['unit_id'] for u in new_labels]
    assert not list(candidate.rglob('*dev*')) and not list(candidate.rglob('*test*'))
    return {'checks':'passed','unit_count':len(units),'changed_unit_count':len(changed),
            'unchanged_unit_count':len(units)-len(changed),'parent_hashes_unchanged':True,
            'ids_order_and_train_membership_preserved':True,'replay_matches':True,
            'blind_source_check':'passed','relation_endpoints_and_evidence':'passed',
            'deferred_and_confirmed_unchanged_preserved':True,'dev_test_included':False}


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base',required=True,type=Path)
    parser.add_argument('--candidate',required=True,type=Path)
    args=parser.parse_args()
    print(json.dumps(validate(args.base,args.candidate),ensure_ascii=False,indent=2))
