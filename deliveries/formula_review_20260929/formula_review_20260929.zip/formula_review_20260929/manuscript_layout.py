from pathlib import Path
import re

from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT

ROOT = Path(__file__).resolve().parent


def font(style, size, east="宋体", bold=False):
    style.font.name = "Times New Roman"
    style.font.size = Pt(size)
    style.font.bold = bold
    style.font.color.rgb = RGBColor(0, 0, 0)
    style.element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), east)


def text(p, s):
    # Keep citation links usable without forcing long URLs into the page width.
    parts = re.split(r"(https?://\S+)", s)
    for item in parts:
        if item.startswith("http"):
            link = OxmlElement("w:hyperlink")
            link.set(qn("r:id"), p.part.relate_to(item, RT.HYPERLINK, is_external=True))
            run = OxmlElement("w:r")
            props = OxmlElement("w:rPr")
            color = OxmlElement("w:color"); color.set(qn("w:val"), "24567A"); props.append(color)
            run.append(props)
            t = OxmlElement("w:t"); t.text = "在线来源"; run.append(t); link.append(run); p._p.append(link)
        else:
            p.add_run(item)


def math_run(value):
    r = OxmlElement("m:r"); t = OxmlElement("m:t"); t.text = value; r.append(t); return r


def equation(doc):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.first_line_indent = Pt(0)
    om = OxmlElement("m:oMath")
    om.append(math_run("L = A + B"))
    sup = OxmlElement("m:sSup")
    base = OxmlElement("m:e"); base.append(math_run("x"))
    exponent = OxmlElement("m:sup"); exponent.append(math_run("c"))
    sup.extend([base, exponent]); om.append(sup); p._p.append(om)
    p.add_run("    （B.2）")


def table(doc, lines):
    rows = [[x.strip() for x in s.strip().strip("|").split("|")] for s in lines]
    rows = [r for r in rows if not all(re.fullmatch(r":?-+:?", c) for c in r)]
    tab = doc.add_table(rows=1, cols=len(rows[0]))
    tab.alignment = WD_TABLE_ALIGNMENT.CENTER
    tab.autofit = False
    widths = [1.5, 2.0, 3.0]
    if rows[0][0] == "集合": widths = [0.85, 0.7, 4.95]
    if rows[0][0] == "编号": widths = [0.55, 2.65, 3.3]
    for col, width in zip(tab.columns, widths): col.width = Inches(width)
    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        e = OxmlElement("w:" + edge); e.set(qn("w:val"), "single"); e.set(qn("w:sz"), "4"); e.set(qn("w:color"), "D9D9D9"); borders.append(e)
    tab._tbl.tblPr.append(borders)
    for i, row_data in enumerate(rows):
        row = tab.rows[0] if i == 0 else tab.add_row()
        trpr = row._tr.get_or_add_trPr(); trpr.append(OxmlElement("w:cantSplit"))
        if i == 0: trpr.append(OxmlElement("w:tblHeader"))
        for j, (cell, value) in enumerate(zip(row.cells, row_data)):
            cell.width = Inches(widths[j]); cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            pr = cell._tc.get_or_add_tcPr()
            margins = OxmlElement("w:tcMar")
            for edge, n in (("top",80),("bottom",80),("left",95),("right",95)):
                e = OxmlElement("w:" + edge); e.set(qn("w:w"), str(n)); e.set(qn("w:type"), "dxa"); margins.append(e)
            pr.append(margins)
            if i == 0:
                shade = OxmlElement("w:shd"); shade.set(qn("w:fill"), "E5EDF3"); pr.append(shade)
            p = cell.paragraphs[0]; p.paragraph_format.first_line_indent = Pt(0)
            p.paragraph_format.space_after = Pt(0); p.paragraph_format.line_spacing = 1.15
            if j == 0 or (rows[0][0] == "集合" and j == 1): p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            r = p.add_run(value); r.bold = i == 0; r.font.size = Pt(11)
    doc.add_paragraph().paragraph_format.space_after = Pt(0)


def main():
    doc = Document()
    sec = doc.sections[0]
    sec.page_width = Inches(8.5); sec.page_height = Inches(11)
    sec.top_margin = sec.bottom_margin = Inches(0.85)
    sec.left_margin = sec.right_margin = Inches(1)
    normal = doc.styles["Normal"]; font(normal, 11.5)
    normal.paragraph_format.line_spacing = 1.35
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.first_line_indent = Pt(23)
    normal.paragraph_format.widow_control = True
    for name, size in (("Title",20),("Heading 1",15),("Heading 2",12.5)):
        st=doc.styles[name]; font(st,size,"黑体",True)
        for border in list(st.element.iter(qn("w:pBdr"))):
            border.getparent().remove(border)
        st.paragraph_format.first_line_indent = Pt(0)
        st.paragraph_format.space_before = Pt(12)
        st.paragraph_format.space_after = Pt(7)
        st.paragraph_format.keep_with_next = True
    header=sec.header.paragraphs[0]
    header.paragraph_format.first_line_indent=Pt(0)
    r=header.add_run("生态评估技术规范知识路径抽取  ·  前四部分重写稿"); r.font.size=Pt(9)
    footer=sec.footer.paragraphs[0]; footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
    footer.paragraph_format.first_line_indent=Pt(0)
    footer.add_run("— ")
    f=OxmlElement("w:fldSimple"); f.set(qn("w:instr"),"PAGE"); footer._p.append(f)
    footer.add_run(" —")
    lines=(ROOT/"论文前四部分更新.md").read_text(encoding="utf-8").splitlines()
    i=0
    while i<len(lines):
        s=lines[i].strip()
        if not s: i+=1; continue
        if s.startswith("|"):
            block=[]
            while i<len(lines) and lines[i].strip().startswith("|"):
                block.append(lines[i]); i+=1
            table(doc,block); continue
        if s=="[FORMULA_B2]": equation(doc)
        elif s.startswith("# "):
            title=s[2:].replace("规范的结构", "规范的\n结构")
            p=doc.add_paragraph(title,"Title"); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
        elif s.startswith("## "):
            doc.add_paragraph(s[3:],"Heading 1")
        elif s.startswith("### "):
            doc.add_paragraph(s[4:],"Heading 2")
        else:
            p=doc.add_paragraph(); text(p,s)
            if s.startswith("表") and len(s)<40:
                p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.first_line_indent=Pt(0); p.paragraph_format.keep_with_next=True
            if s.startswith("前四部分") or s.startswith("稿件说明"):
                p.paragraph_format.first_line_indent=Pt(0)
                for r in p.runs: r.font.size=Pt(10.5)
            if re.match(r"^\[\d+\]",s):
                p.paragraph_format.first_line_indent=Pt(0)
        i+=1
    doc.core_properties.title="面向生态评估技术规范的结构感知与证据约束知识路径抽取方法"
    doc.core_properties.subject="前四部分重写稿"
    doc.save(ROOT/"生态论文前四部分更新稿_20260929.docx")


if __name__=="__main__": main()
